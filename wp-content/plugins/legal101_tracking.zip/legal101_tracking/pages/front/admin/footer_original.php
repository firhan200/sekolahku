<?php
wp_footer();
?>